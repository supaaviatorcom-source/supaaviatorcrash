AVIATOR CRASH DEMO — INSTALLABLE WEB APP

Upload ALL files in this folder to GitHub Pages (or another HTTPS web host).
Open the public HTTPS URL on Android Chrome and choose "Install app" / "Add to Home screen".

This package is a DEMO and uses virtual credits only. It does not implement real-money
deposits, withdrawals, payment processing, or gambling.

For a public app-store release, create a store-compliant Android/iOS package and follow
the applicable store, gambling, age-rating, payment, and local-law requirements.
